
/********************************************************************** API info **********************************************************************/
const baseUrl = "https://api.themoviedb.org/3/discover/movie?";
const apiKey = "api_key=fd04553a9b46f1ae874f30e7849926e8&";
const afterEnd = "language=en-US&sort_by=release_date.desc&page=1&with_genres="

// categories we use: 
const moodSelect = document.getElementById("mood-select");
const movieSec = document.getElementById("movie");


/********************************************************************** Function to make the actual movie card: **********************************************************************/
function makingMovieCard(content) {

//movie card container
    const movieContainer = document.createElement('div');
    movieContainer.classList.add(`movie__container`);
    movieContainer.classList.add(`active`);

//Adding title
    const movieTitle = document.createElement('h2');
    movieTitle.classList.add(`movie__title`);
    movieTitle.innerHTML = content.title;

//adding movie info
    const description = document.createElement('p');
    description.classList.add('movie__description');
    description.innerHTML = content.overview;

//adding movie poster
    const poster = document.createElement('div');
    poster.classList.add('movie__poster');
    const posterUrl = 'https://image.tmdb.org/t/p/w500' + content.poster_path;
    const posterImage = document.createElement('img');
    posterImage.src = posterUrl;
    poster.appendChild(posterImage);
    
//Appending the kida to container
    movieContainer.appendChild(movieTitle);
    movieContainer.appendChild(poster);
    movieContainer.appendChild(description);

    return movieContainer;
}

const panels = document.querySelectorAll(`.movie__container`)

panels.forEach(panel => {
    panel.addEventListener('click', () => {
        removeActiveClasses()
        panel.classList.add('active')
    })
})

function removeActiveClasses() {
    panels.forEach(panel => {
        panel.classList.remove('active')
    })
}


/********************************************************************** When someone selects their mood: this will run**********************************************************************/
moodSelect.addEventListener("change", () => {

const selectedCategory = moodSelect.value;
const apiURL = baseUrl + apiKey + afterEnd + selectedCategory;

console.log(apiURL);

axios.get(apiURL).then((result) => {
    const movies = result.data.results;
    movieSec.innerHTML = ""; 

    movies.forEach((movie) => {
        const movieCard = makingMovieCard(movie);
        movieSec.appendChild(movieCard);
    });
    }).catch((error) => {
    console.log(error);
    });
});

